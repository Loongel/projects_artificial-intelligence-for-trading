/* cstore_fdw/cstore_fdw--1.2--1.3.sql */

-- No new functions or definitions were added in 1.3
